import json
import os
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pipeline.config import NystagmusConfig, VERTICAL_LABELS, HORIZONTAL_LABELS  # noqa: E402
from pipeline.mock import mock_meta, mock_table, table_from_positions, sawtooth  # noqa: E402
from pipeline.nystagmus_stage import detect_axis  # noqa: E402
from pipeline.run import assemble_result  # noqa: E402


def run(kind, **kw):
    return assemble_result(mock_table(kind, **kw), mock_meta())


def test_downbeat():
    r = run("DBN")
    v = r["nystagmus"]["vertical"]
    assert v["label"] == "DBN", v
    assert v["accepted_beats"] >= 10 and v["direction_consistency"] == 1.0
    assert v["median_spv"] > 0                           # slow phase upward
    assert r["nystagmus"]["horizontal"]["label"] == "Neither detected"
    assert r["overall"] == "nystagmus_detected"


def test_upbeat():
    v = run("UBN")["nystagmus"]["vertical"]
    assert v["label"] == "UBN" and v["median_spv"] < 0


def test_right_and_left_beating():
    assert run("RIGHT")["nystagmus"]["horizontal"]["label"] == "Right-beating"
    assert run("LEFT")["nystagmus"]["horizontal"]["label"] == "Left-beating"


def test_none():
    r = run("NONE")
    assert r["overall"] == "not_detected"
    assert r["nystagmus"]["vertical"]["label"] == "Neither detected"


def test_both_directions_is_inconclusive():
    """Half right-beating, half left-beating (the situation in geotropic_nystagmus.csv)."""
    fps, n = 30.0, 1200
    t = np.arange(n) / fps
    rng = np.random.default_rng(3)
    hor = sawtooth(t, +1, 1, 19) + sawtooth(t, -1, 21, 39) + rng.normal(0, 0.05, n)
    tab = table_from_positions(t, hor, rng.normal(0, 0.05, n), fps)
    h = assemble_result(tab, mock_meta())["nystagmus"]["horizontal"]
    assert h["label"] == "Inconclusive (conflicting patterns)", h
    assert 0.45 <= h["direction_consistency"] <= 0.55


def test_nan_gap_does_not_crash_and_beats_do_not_span_it():
    tab = mock_table("DBN")
    gap = (tab["time_s"] > 8) & (tab["time_s"] < 9.5)
    tab.loc[gap, "ver_interp"] = np.nan
    r = assemble_result(tab, mock_meta())
    v = r["nystagmus"]["vertical"]
    assert v["label"] == "DBN"
    for b in v["beats"]:
        assert not (b["start"] < 8 and b["end"] > 9.5)
    json.dumps(r, allow_nan=False)                        # NaN became null


def test_blink_overlap_rejection_is_switchable():
    tab = mock_table("DBN")
    t = tab["time_s"].to_numpy()
    blink = ((t > 6.0) & (t < 6.2)).astype(int)
    tab["blink"] = blink
    on = detect_axis(t, tab["ver_interp"].to_numpy(), VERTICAL_LABELS, NystagmusConfig(reject_blink_overlap=True), blink)
    off = detect_axis(t, tab["ver_interp"].to_numpy(), VERTICAL_LABELS, NystagmusConfig(reject_blink_overlap=False), blink)
    assert on["accepted_beats"] < off["accepted_beats"]
    assert on["rejections"].get("touches_blink", 0) >= 1


def test_flat_signal_is_reported_not_silent():
    n = 300
    t = np.arange(n) / 30.0
    r = detect_axis(t, np.zeros(n), VERTICAL_LABELS)
    assert r["label"] == "Neither detected" and r["notes"]


def test_noise_free_beats_are_missed_by_the_mad_rule():
    """Documents a limit of the notebook's detector: perfectly clean synthetic beats give MAD = 0."""
    n = 1200
    t = np.arange(n) / 30.0
    r = detect_axis(t, sawtooth(t, -1, 1, 39), VERTICAL_LABELS)
    assert r["label"] == "Neither detected" and "MAD" in r["notes"][0]


def test_too_short_signal():
    t = np.arange(5) / 30.0
    r = detect_axis(t, np.zeros(5), VERTICAL_LABELS)
    assert r["label"] == "Neither detected" and "No gap-free stretch" in r["notes"][0]


def test_result_is_json_safe_and_has_app_keys():
    r = run("DBN")
    s = json.dumps(r, allow_nan=False)
    assert len(s) < 2_000_000
    for k in ("timestamps", "horizontal_angle", "vertical_angle", "nystagmus_segments", "warnings"):
        assert k in r
    n = len(r["timestamps"])
    assert all(len(r[k]) == n for k in ("horizontal_angle", "vertical_angle", "velocity_h", "velocity_v", "spv_h", "spv_v", "blink"))
    seg = r["nystagmus_segments"][0]
    assert {"axis", "start", "end"} <= set(seg)           # what the Flutter model already parses


def test_server_end_to_end_mock():
    os.environ["MOCK_PIPELINE"] = "1"
    os.environ["API_KEY"] = "secret"
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "server"))
    import importlib
    import app as server_app
    importlib.reload(server_app)
    from fastapi.testclient import TestClient
    c = TestClient(server_app.app)
    assert c.get("/health").json() == {"ok": True, "mock": True}
    files = {"video": ("eye.mp4", b"not a real video", "video/mp4")}
    assert c.post("/analyze", files=files).status_code == 401          # no key
    h = {"x-api-key": "secret"}
    job = c.post("/analyze", files=files, headers=h).json()["job_id"]
    assert c.get(f"/jobs/{job}").status_code == 401
    status = None
    for _ in range(40):
        status = c.get(f"/jobs/{job}", headers=h).json()
        if status["status"] != "processing":
            break
        time.sleep(0.25)
    assert status["status"] == "done", status
    assert status["result"]["nystagmus"]["vertical"]["label"] == "DBN"
    assert c.get("/jobs/nope", headers=h).status_code == 404
    assert c.post("/analyze", files={"video": ("e.mp4", b"", "video/mp4")}, headers=h).status_code == 400
    assert not list(server_app.UPLOAD_DIR.glob("*.mp4"))                # upload deleted after processing
