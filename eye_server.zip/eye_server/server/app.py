"""FastAPI wrapper. Same contract the phone app already uses:

  POST /analyze        multipart field "video"  ->  {"job_id": "..."}
  GET  /jobs/{job_id}  ->  {"status": "processing" | "done" | "failed", "result": {...}, "error": "..."}
  GET  /health

Environment variables:
  MOCK_PIPELINE=1   skip EllSeg, return a synthetic recording (for testing the app/network without a GPU)
  MOCK_KIND=DBN     which synthetic pattern (DBN, UBN, RIGHT, LEFT, NONE)
  API_KEY=...       if set, every call must send the header  X-API-Key: <value>
  KEEP_VIDEOS=1     keep uploaded videos on the server (default: deleted right after processing)
  MAX_UPLOAD_MB=300
"""
import os
import tempfile
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from fastapi import FastAPI, File, Header, HTTPException, UploadFile

MOCK = os.environ.get("MOCK_PIPELINE", "0") == "1"
MOCK_KIND = os.environ.get("MOCK_KIND", "DBN")
API_KEY = os.environ.get("API_KEY", "")
KEEP_VIDEOS = os.environ.get("KEEP_VIDEOS", "0") == "1"
MAX_BYTES = int(os.environ.get("MAX_UPLOAD_MB", "300")) * 1024 * 1024
JOB_TTL_S = 3600

app = FastAPI(title="Eye gaze nystagmus analysis")
_pool = ThreadPoolExecutor(max_workers=1)          # one video at a time: the GPU model is not shared safely
_jobs, _lock = {}, threading.Lock()
_runner = None
UPLOAD_DIR = Path(tempfile.gettempdir()) / "eye_uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


def _check_key(x_api_key):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid or missing API key.")


def _get_runner():
    global _runner
    if _runner is None:
        from pipeline.ellseg_stage import EllSegRunner
        _runner = EllSegRunner()
        _runner.load()
    return _runner


def _process(job_id, path):
    try:
        if MOCK:
            from pipeline.mock import mock_meta, mock_table
            from pipeline.run import assemble_result
            time.sleep(2)                                  # pretend to work, so the app's progress screen is exercised
            result = assemble_result(mock_table(MOCK_KIND), mock_meta(), ["Mock data: no real video was analysed."])
        else:
            from pipeline.run import analyze
            result = analyze(path, _get_runner())
        with _lock:
            _jobs[job_id].update(status="done", result=result)
    except Exception as exc:                               # the phone gets a readable message, the server log gets the trace
        import traceback; traceback.print_exc()
        with _lock:
            _jobs[job_id].update(status="failed", error=str(exc)[:300])
    finally:
        if not KEEP_VIDEOS:
            Path(path).unlink(missing_ok=True)


def _expire_old_jobs():
    cutoff = time.time() - JOB_TTL_S
    with _lock:
        for k in [k for k, v in _jobs.items() if v["created"] < cutoff]:
            del _jobs[k]


@app.get("/health")
def health():
    return {"ok": True, "mock": MOCK}


@app.post("/analyze")
async def analyze_video(video: UploadFile = File(...), x_api_key: str = Header(default="")):
    _check_key(x_api_key)
    _expire_old_jobs()
    job_id = uuid.uuid4().hex
    suffix = Path(video.filename or "eye.mp4").suffix or ".mp4"
    path = UPLOAD_DIR / f"{job_id}{suffix}"
    size = 0
    with open(path, "wb") as f:
        while chunk := await video.read(1 << 20):
            size += len(chunk)
            if size > MAX_BYTES:
                f.close(); path.unlink(missing_ok=True)
                raise HTTPException(status_code=413, detail="Video too large.")
            f.write(chunk)
    if size == 0:
        path.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail="Empty upload.")
    with _lock:
        _jobs[job_id] = {"status": "processing", "result": None, "error": None, "created": time.time()}
    _pool.submit(_process, job_id, str(path))
    return {"job_id": job_id}


@app.get("/jobs/{job_id}")
def job_status(job_id: str, x_api_key: str = Header(default="")):
    _check_key(x_api_key)
    with _lock:
        job = _jobs.get(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Unknown job.")
        return {"status": job["status"], "result": job["result"], "error": job["error"]}
