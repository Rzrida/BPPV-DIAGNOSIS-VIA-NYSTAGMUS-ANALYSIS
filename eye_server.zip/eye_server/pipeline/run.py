"""The one function the server calls: video file in -> JSON-safe result dict out."""
import tempfile
import time
from pathlib import Path

import numpy as np

from .config import (CropConfig, EllSegConfig, NystagmusConfig, VERTICAL_LABELS, HORIZONTAL_LABELS)
from .nystagmus_stage import detect_axis, merge_beats_to_segments

NO_CALL = "Neither detected"


def _clean(a, nd=3):
    """numpy -> plain list; NaN/inf become None (JSON has no NaN)."""
    a = np.asarray(a, float)
    return [None if not np.isfinite(x) else round(float(x), nd) for x in a]


def assemble_result(table, meta, warnings=None, ny_cfg=None):
    """Run the nystagmus stage on the gaze table and build the JSON the app receives."""
    ny_cfg = ny_cfg or NystagmusConfig()
    warnings = list(warnings or [])
    t = table["time_s"].to_numpy(float)
    blink = table["blink"].to_numpy(bool)

    vertical = detect_axis(t, table["ver_interp"].to_numpy(float), VERTICAL_LABELS, ny_cfg, blink)
    horizontal = detect_axis(t, table["hor_interp"].to_numpy(float), HORIZONTAL_LABELS, ny_cfg, blink)

    def is_call(r):
        return r["label"] != NO_CALL and not r["label"].startswith("Inconclusive")

    if is_call(vertical) or is_call(horizontal):
        overall = "nystagmus_detected"
        headline = "; ".join(f"{name}: {r['label']}" for name, r in (("Vertical", vertical), ("Horizontal", horizontal)) if is_call(r))
    elif vertical["label"].startswith("Inconclusive") or horizontal["label"].startswith("Inconclusive"):
        overall, headline = "inconclusive", "Inconclusive: the signal did not give a clear call."
    else:
        overall, headline = "not_detected", "No nystagmus detected."

    unit = meta.get("unit", "deg")
    if meta.get("angle_mode") == "approx_iris_ruler":
        warnings.append("Angles are approximate: the iris width was used as the scale (eyeball model not usable).")
    if meta.get("angle_mode") == "pixels":
        warnings.append("Angles are in pixels, not degrees: velocity thresholds are not meaningful.")
    n = len(t)
    if n and blink.mean() > 0.3:
        warnings.append(f"{100 * blink.mean():.0f}% of frames were blinks or covered: results may be unreliable.")
    if n and t[-1] < 5:
        warnings.append("The recording is short (under 5 seconds): too short to judge repeated beats.")
    for name, r in (("vertical", vertical), ("horizontal", horizontal)):
        warnings += [f"{name}: {x}" for x in r["notes"]]

    segments = (merge_beats_to_segments(vertical["beats"], "vertical")
                + merge_beats_to_segments(horizontal["beats"], "horizontal"))

    return {
        "meta": {**meta, "unit": unit, "n_frames": int(n), "duration_s": round(float(t[-1]), 3) if n else 0.0,
                 "blink_frames": int(blink.sum())},
        "overall": overall,
        "headline": headline,
        "timestamps": _clean(t, 4),
        "horizontal_angle": _clean(table["hor_interp"]),
        "vertical_angle": _clean(table["ver_interp"]),
        "velocity_h": _clean(table["vel_h_s"]),
        "velocity_v": _clean(table["vel_v_s"]),
        "spv_h": _clean(table["spv_h_s"]),
        "spv_v": _clean(table["spv_v_s"]),
        "blink": [int(x) for x in blink],
        "nystagmus": {"vertical": vertical, "horizontal": horizontal},
        "nystagmus_segments": segments,
        "warnings": warnings,
    }


def analyze(video_path, runner, workdir=None, crop_cfg=None, ell_cfg=None, ny_cfg=None):
    """Full pipeline on one video file."""
    from .eye_crop import ensure_readable, find_eye_crop, write_cropped_video
    from .ellseg_stage import detect_blinks, estimate_gaze_angles
    from .gaze_signal import build_signal

    crop_cfg, ell_cfg, ny_cfg = crop_cfg or CropConfig(), ell_cfg or EllSegConfig(), ny_cfg or NystagmusConfig()
    timings, t0 = {}, time.time()

    def lap(name):
        nonlocal t0
        timings[name] = round(time.time() - t0, 2); t0 = time.time()

    own = tempfile.TemporaryDirectory() if workdir is None else None
    work = Path(own.name if own else workdir)
    try:
        readable = ensure_readable(video_path, work); lap("read_video")
        crop = find_eye_crop(readable, crop_cfg); lap("find_eye")
        cropped = work / "cropped_eye.mp4"
        write_cropped_video(readable, crop, cropped); lap("crop")
        m = runner.process(cropped); lap("ellseg")
        detect_blinks(m, ell_cfg)
        angles = estimate_gaze_angles(m, ell_cfg); lap("eyeball_model")
        table, info = build_signal(m, angles, m["fps"], ell_cfg); lap("signal")
        warnings = [angles["note"]] if angles.get("note") and not angles["have_angles"] else []
        if angles.get("note") and angles["have_angles"]:
            warnings.append(angles["note"])
        meta = {"fps": round(m["fps"], 3), "unit": info["unit"], "angle_mode": info["angle_mode"],
                "valid_frames": info["valid_frames"], "eyeball_radius_mm": angles.get("radius_mm"),
                "crop": {k: crop[k] for k in ("x0", "y0", "w", "h")}}
        result = assemble_result(table, meta, warnings, ny_cfg); lap("nystagmus")
        result["meta"]["timings_s"] = timings
        return result
    finally:
        if own:
            own.cleanup()
