"""Stage 1c: turn per-frame eye measurements into the gaze table. Port of ellseg cell 3."""
import numpy as np
import pandas as pd
from scipy.ndimage import binary_dilation
from scipy.signal import savgol_filter

from .config import EllSegConfig


def fill_gaps(x, max_gap):
    """Bridge NaN gaps of at most max_gap samples by straight lines; longer gaps stay NaN."""
    x = np.asarray(x, float); out = x.copy(); n = len(x); ok = np.isfinite(x)
    if ok.sum() < 2:
        return out
    idx = np.arange(n); filled = np.interp(idx, idx[ok], x[ok]); i = 0
    while i < n:
        if ok[i]:
            i += 1; continue
        j = i
        while j < n and not ok[j]:
            j += 1
        if i > 0 and j < n and (j - i) <= max_gap:
            out[i:j] = filled[i:j]
        i = j
    return out


def velocity(x, fps, vel_win_s):
    x = np.asarray(x, float); ok = np.isfinite(x)
    if ok.sum() < 7:
        return np.full(len(x), np.nan)
    xi = np.interp(np.arange(len(x)), np.flatnonzero(ok), x[ok])
    w = max(5, int(round(vel_win_s * fps))); w += (w % 2 == 0)
    if w > len(x):
        w = len(x) - (len(x) % 2 == 0)
    v = savgol_filter(xi, w, 2, deriv=1, delta=1.0 / fps)
    v[~ok] = np.nan
    return v


def qp_threshold(v):
    d = np.abs(v - np.nanmedian(v)); d = d[np.isfinite(d)]
    if d.size == 0:
        return np.inf
    return max(5 * 1.4826 * np.median(d), 0.3 * np.percentile(d, 99))


def slow_phase_velocity(v, thr, fps, cfg):
    base = np.nanmedian(v)
    quick = np.isfinite(v) & (np.abs(v - base) > thr)
    pad = binary_dilation(quick, structure=np.ones(2 * cfg.qp_pad + 1, bool))
    slow = np.where(np.isfinite(v) & ~pad, v, np.nan)
    win = max(5, int(round(cfg.spv_win_s * fps)))
    spv = pd.Series(slow).rolling(win, center=True, min_periods=max(3, win // 5)).median().to_numpy()
    return spv, quick


def build_signal(m, angles, fps, cfg=None):
    """
    m      : dict from EllSegRunner.process + detect_blinks (pe_arr, ie_arr, found, blink, occl, cw, ch, net_h, net_w)
    angles : dict from estimate_gaze_angles (have_angles, hor, ver)
    Returns (DataFrame, info). Positive = right / up in the VIDEO view.
    """
    cfg = cfg or EllSegConfig()
    pe_arr, ie_arr = m["pe_arr"], m["ie_arr"]
    found, blink = m["found"], m["blink"]
    N = len(pe_arr)
    CW, CH, NET_W, NET_H = m["cw"], m["ch"], m["net_w"], m["net_h"]
    valid = found & ~blink
    have = bool(angles["have_angles"])
    if have:
        hor, ver = angles["hor"], angles["ver"]
        valid = valid & np.isfinite(hor) & np.isfinite(ver)
    if not valid.any():
        raise ValueError("No valid eye frames were found in the video.")

    unit, mode = "px", "pixels"
    if have:
        unit, mode = "deg", "eyeball_model"
        sh_raw, sv_raw = hor.copy(), ver.copy()
        sh_raw[~valid] = np.nan; sv_raw[~valid] = np.nan
    else:
        pupil_x = pe_arr[:, 0] * (CW / NET_W)
        pupil_y = pe_arr[:, 1] * (CH / NET_H)
        sh_raw = np.where(valid, pupil_x, np.nan)
        sv_raw = np.where(valid, -pupil_y, np.nan)
        sh_raw = sh_raw - np.nanmedian(sh_raw)
        sv_raw = sv_raw - np.nanmedian(sv_raw)
        if cfg.approx_deg:
            ir = np.maximum(ie_arr[:, 2], ie_arr[:, 3]); ir = ir[np.isfinite(ir)]
            if ir.size > 10:
                mm_per_px = cfg.iris_diam_mm / (2 * np.median(ir) * (CW / NET_W))
                sh_raw = np.degrees(np.arcsin(np.clip(sh_raw * mm_per_px / cfg.eye_r_mm, -1, 1)))
                sv_raw = np.degrees(np.arcsin(np.clip(sv_raw * mm_per_px / cfg.eye_r_mm, -1, 1)))
                unit, mode = "deg", "approx_iris_ruler"

    # flips apply in every mode (the notebook applied them only to eyeball-model angles; defaults are off)
    if cfg.flip_horizontal: sh_raw = -sh_raw
    if cfg.flip_vertical: sv_raw = -sv_raw

    max_gap = int(round(cfg.max_gap_s * fps))
    H_i, V_i = fill_gaps(sh_raw, max_gap), fill_gaps(sv_raw, max_gap)
    vel_h, vel_v = velocity(H_i, fps, cfg.vel_win_s), velocity(V_i, fps, cfg.vel_win_s)
    speed = np.hypot(vel_h, vel_v)
    real = have
    thr_h = cfg.qp_vel if real else qp_threshold(vel_h)
    thr_v = cfg.qp_vel if real else qp_threshold(vel_v)
    spv_h, quick_h = slow_phase_velocity(vel_h, thr_h, fps, cfg)
    spv_v, quick_v = slow_phase_velocity(vel_v, thr_v, fps, cfg)

    t = np.arange(N) / fps
    df = pd.DataFrame({
        "time_s": t, "hor_interp": H_i, "ver_interp": V_i, "speed_s": speed,
        "vel_h_s": vel_h, "vel_v_s": vel_v, "spv_h_s": spv_h, "spv_v_s": spv_v,
        "quick_phase_h": quick_h.astype(int), "quick_phase_v": quick_v.astype(int),
        "blink": blink.astype(int), "occlusion": m["occl"],
    })
    return df, {"unit": unit, "angle_mode": mode, "valid_frames": int(valid.sum())}
