"""Synthetic gaze tables for testing without a GPU / without EllSeg.
The tables go through the REAL nystagmus stage, so the JSON the app receives is realistic."""
import numpy as np
import pandas as pd

from .config import EllSegConfig
from .gaze_signal import qp_threshold, slow_phase_velocity, velocity

SLOW_S, FAST_S, SLOW_SPEED = 0.7, 0.1, 4.0            # seconds, seconds, deg/s
AMP = SLOW_S * SLOW_SPEED                              # degrees per beat


def sawtooth(t, direction, t_start, t_end):
    """Jerk nystagmus: slow drift opposite to `direction`, fast return in `direction` (+1 up/right, -1 down/left)."""
    period = SLOW_S + FAST_S
    phase = (t - t_start) % period
    drift = np.where(phase < SLOW_S, SLOW_SPEED * phase, AMP - AMP * (phase - SLOW_S) / FAST_S)   # goes up, then jumps down
    pos = -direction * drift                           # fast phase direction = `direction`
    pos = pos + direction * AMP / 2                    # keep it roughly centred
    return np.where((t >= t_start) & (t < t_end), pos, 0.0)


def table_from_positions(t, hor, ver, fps, blink=None, cfg=None):
    cfg = cfg or EllSegConfig()
    blink = np.zeros(len(t), int) if blink is None else np.asarray(blink, int)
    vel_h, vel_v = velocity(hor, fps, cfg.vel_win_s), velocity(ver, fps, cfg.vel_win_s)
    spv_h, qh = slow_phase_velocity(vel_h, qp_threshold(vel_h), fps, cfg)
    spv_v, qv = slow_phase_velocity(vel_v, qp_threshold(vel_v), fps, cfg)
    return pd.DataFrame({
        "time_s": t, "hor_interp": hor, "ver_interp": ver, "speed_s": np.hypot(vel_h, vel_v),
        "vel_h_s": vel_h, "vel_v_s": vel_v, "spv_h_s": spv_h, "spv_v_s": spv_v,
        "quick_phase_h": qh.astype(int), "quick_phase_v": qv.astype(int),
        "blink": blink, "occlusion": np.zeros(len(t)),
    })


def mock_table(kind="DBN", seconds=20.0, fps=30.0, seed=7, noise=0.05):
    """kind: DBN, UBN, RIGHT, LEFT or NONE."""
    rng = np.random.default_rng(seed)
    n = int(seconds * fps)
    t = np.arange(n) / fps
    hor, ver = np.zeros(n), np.zeros(n)
    t0, t1 = 0.15 * seconds, 0.85 * seconds
    if kind == "DBN":
        ver = sawtooth(t, -1, t0, t1)
    elif kind == "UBN":
        ver = sawtooth(t, +1, t0, t1)
    elif kind == "RIGHT":
        hor = sawtooth(t, +1, t0, t1)
    elif kind == "LEFT":
        hor = sawtooth(t, -1, t0, t1)
    hor = hor + rng.normal(0, noise, n)
    ver = ver + rng.normal(0, noise, n)
    return table_from_positions(t, hor, ver, fps)


def mock_meta(fps=30.0):
    return {"fps": fps, "unit": "deg", "angle_mode": "mock", "valid_frames": 0, "eyeball_radius_mm": None}
