"""Stage 1b: EllSeg on every frame, blink/occlusion detection, DeepVOG eyeball-model angles.
Port of ellseg cell 2. Needs torch (and a GPU is strongly preferred) plus the EllSeg and DeepVOG repos."""
import argparse
import subprocess
import sys
import types
import warnings
from pathlib import Path

import cv2
import numpy as np
from scipy.ndimage import binary_dilation

from .config import EllSegConfig


def _patch_numpy():
    # EllSeg / DeepVOG use np.int, np.float, ...: must run BEFORE importing them
    for n, v in [("float", float), ("int", int), ("int0", np.intp), ("mat", np.asmatrix),
                 ("bool", bool), ("object", object)]:
        if not hasattr(np, n):
            setattr(np, n, v)


def _frames_rgb(path):
    cap = cv2.VideoCapture(str(path))
    while True:
        ok, f = cap.read()
        if not ok:
            break
        yield cv2.cvtColor(f, cv2.COLOR_BGR2RGB)
    cap.release()


def pupil_contrast(g, pm):
    """(surround - pupil) / surround on the REAL pixels under EllSeg's pupil mask.
    Open eye -> high. Closed / covered by the lid -> about 0."""
    n = int(pm.sum())
    if n < 20:
        return np.nan
    r = max(3, int(0.6 * np.sqrt(n / np.pi)))
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1, 2 * r + 1))
    ring = (cv2.dilate(pm.astype(np.uint8), k) > 0) & ~pm
    if ring.sum() < 10:
        return np.nan
    inside, outside = float(g[pm].mean()), float(g[ring].mean())
    return (outside - inside) / max(outside, 1.0)


class EllSegRunner:
    """Loads the network once (slow) and then processes any number of videos."""

    def __init__(self, cfg=None):
        self.cfg = cfg or EllSegConfig()
        self.model = None
        self.device = None
        self.ES = None
        self.torch = None

    def load(self):
        if self.model is not None:
            return
        cfg = self.cfg
        _patch_numpy()
        repo = Path(cfg.repo_dir)
        if not repo.exists():
            subprocess.run(["git", "clone", "--depth", "1", "https://github.com/RSKothari/EllSeg.git", str(repo)], check=True)
        w_path = repo / "weights" / cfg.weights
        if not w_path.exists() or w_path.stat().st_size < 1_000_000:
            raise FileNotFoundError(f"EllSeg weights not found or too small: {w_path}")
        import torch
        warnings.filterwarnings("ignore")
        sys.path.insert(0, str(repo.resolve()))
        import evaluate_ellseg as ES
        from modelSummary import model_dict
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        try:
            net = torch.load(str(w_path), map_location=self.device, weights_only=False)
        except TypeError:
            net = torch.load(str(w_path), map_location=self.device)
        model = model_dict["ritnet_v3"]
        model.load_state_dict(net["state_dict"], strict=True)
        model.to(self.device).eval()
        ES.args = argparse.Namespace(ellseg_ellipses=cfg.ellipses, skip_ransac=0)
        self.ES, self.model, self.torch = ES, model, torch

    def _prep(self, rgb):
        cfg = self.cfg
        g = cv2.resize(cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY), (cfg.net_w, cfg.net_h), interpolation=cv2.INTER_LANCZOS4)
        gf = g.astype(np.float32)
        t = self.torch.from_numpy((gf - gf.mean()) / (gf.std() + 1e-6)).unsqueeze(0).unsqueeze(0)
        return g, t

    def process(self, cropped_video):
        """Run EllSeg on EVERY frame. Returns raw per-frame measurements."""
        self.load()
        cfg = self.cfg
        cap = cv2.VideoCapture(str(cropped_video))
        cw, ch = int(cap.get(3)), int(cap.get(4))
        fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        cap.release()

        nan5 = np.full(5, np.nan)

        def valid_ellipse(e):
            e = np.asarray(e, float)
            return bool(e.shape[0] >= 5 and np.all(np.isfinite(e[:5])) and e[2] > 1 and e[3] > 1
                        and 0 <= e[0] < cfg.net_w and 0 <= e[1] < cfg.net_h)

        pe_l, ie_l, con_l = [], [], []
        with self.torch.no_grad():
            for i, f in enumerate(_frames_rgb(cropped_video)):
                g, t_in = self._prep(f)
                pe, ie, con = nan5, nan5, np.nan
                if g.max() >= 20:                                   # almost-black frames are skipped
                    try:
                        seg, _, pe_, ie_ = self.ES.evaluate_ellseg_on_image(t_in.to(self.device), self.model)
                        pe_ = np.asarray(pe_, float).reshape(-1)[:5]
                        ie_ = np.asarray(ie_, float).reshape(-1)[:5]
                        seg = np.asarray(seg)
                        con = pupil_contrast(g, seg == 2)
                        if valid_ellipse(pe_): pe = pe_
                        if valid_ellipse(ie_): ie = ie_
                    except Exception:
                        pass
                pe_l.append(pe); ie_l.append(ie); con_l.append(con)
        if not pe_l:
            raise ValueError("No frames in the cropped video.")
        return {"pe_arr": np.array(pe_l), "ie_arr": np.array(ie_l), "contrast": np.array(con_l, float),
                "fps": float(fps), "cw": cw, "ch": ch, "net_w": cfg.net_w, "net_h": cfg.net_h}


def detect_blinks(m, cfg):
    """Blink + occlusion detection (notebook logic). Adds found/blink/partial/occl/ratio to m."""
    pe_arr, contrast = m["pe_arr"], m["contrast"]
    found = np.isfinite(pe_arr[:, 0])
    if not found.any():
        raise ValueError("EllSeg found no pupil in any frame (is the eye visible and in focus?).")
    ratio = np.maximum(pe_arr[:, 2], pe_arr[:, 3]) / np.maximum(np.minimum(pe_arr[:, 2], pe_arr[:, 3]), 1e-6)
    ref_con = np.nanpercentile(contrast[np.isfinite(contrast)], 75) if np.isfinite(contrast).any() else 1.0
    bad = (~found) | (~np.isfinite(contrast)) | (contrast < cfg.blink_min_contrast_frac * ref_con) \
        | (np.nan_to_num(ratio, nan=1.0) > cfg.blink_max_axis_ratio)
    blink = binary_dilation(bad, structure=np.ones(2 * cfg.blink_pad + 1, bool))
    occl = np.clip(1.0 - np.nan_to_num(contrast, nan=0.0) / max(ref_con, 1e-6), 0, 1)
    partial = (occl > cfg.partial_occ) & ~blink & found
    m.update(found=found, ratio=ratio, blink=blink, occl=occl, partial=partial, ref_con=float(ref_con))
    return m


# ----------------------------------------------------------------------------------------------
# DeepVOG eyeball model -> gaze angles (same fitter, constants and angle function as the notebook)
# ----------------------------------------------------------------------------------------------
def _import_fitter(dv_dir):
    dv_dir = Path(dv_dir)
    if not dv_dir.exists():
        subprocess.run(["git", "clone", "--depth", "1", "https://github.com/pydsgz/DeepVOG.git", str(dv_dir)], check=True)
    if str(dv_dir.resolve()) not in sys.path:
        sys.path.append(str(dv_dir.resolve()))                # append: EllSeg's modules keep priority
    try:
        if "deepvog" not in sys.modules:                      # stub package skips deepvog/__init__ (pulls in TensorFlow)
            pkg = types.ModuleType("deepvog"); pkg.__path__ = [str(dv_dir.resolve() / "deepvog")]
            sys.modules["deepvog"] = pkg
        from deepvog.eyefitter import SingleEyeFitter
        from deepvog.ellipses import LSqEllipse
    except Exception:
        for k in [k for k in sys.modules if k == "deepvog" or k.startswith("deepvog.")]:
            del sys.modules[k]
        from deepvog.eyefitter import SingleEyeFitter
        from deepvog.ellipses import LSqEllipse

    def _safe_params(self):
        c = self._center
        return (np.array([np.real(c[0]), np.real(c[1])], dtype=float),
                float(np.real(self._width)), float(np.real(self._height)), float(np.real(self._phi)))
    LSqEllipse.parameters = _safe_params
    return SingleEyeFitter


def _vec_to_angles(n):
    n = np.asarray(n, float).reshape(3); n = n / np.linalg.norm(n)
    h = np.degrees(np.arctan2(n[0], abs(n[2])))        # + = right
    v = np.degrees(-np.arcsin(np.clip(n[1], -1, 1)))   # + = up
    return h, v


def estimate_gaze_angles(m, cfg):
    """Fit DeepVOG's eyeball model on clear open-eye frames; return per-frame angles or have_angles=False."""
    pe_arr, found, blink, partial, ratio = m["pe_arr"], m["found"], m["blink"], m["partial"], m["ratio"]
    N = len(pe_arr)
    NET_H, NET_W = m["net_h"], m["net_w"]
    out = {"have_angles": False, "hor": np.full(N, np.nan), "ver": np.full(N, np.nan),
           "radius_mm": None, "consistent_frac": None, "note": None}
    if not cfg.use_eyeball_model:
        out["note"] = "Eyeball model disabled in settings."
        return out
    try:
        SingleEyeFitter = _import_fitter(cfg.deepvog_dir)
    except Exception as exc:
        out["note"] = f"DeepVOG could not be imported: {repr(exc)[:150]}"
        return out

    MM2PX = np.linalg.norm((NET_H, NET_W)) / np.linalg.norm(cfg.sensor_mm)
    fitter = SingleEyeFitter(focal_length=cfg.focal_length_mm * MM2PX, pupil_radius=2.0 * MM2PX,
                             initial_eye_z=50.0 * MM2PX)
    SS = 4

    def ellipse_to_map(e):
        cx, cy, a_, b_, th = e
        mp = np.zeros((NET_H * SS, NET_W * SS), np.uint8)
        cv2.ellipse(mp, (int(round(cx * SS)), int(round(cy * SS))),
                    (max(1, int(round(a_ * SS))), max(1, int(round(b_ * SS)))), float(np.degrees(th)), 0, 360, 255, -1)
        return cv2.resize(mp, (NET_W, NET_H), interpolation=cv2.INTER_AREA).astype(np.float32) / 255.0

    obs = [None] * N
    with np.errstate(all="ignore"):
        for i in range(N):
            if not found[i]:
                continue
            try:
                gp, gn, pp, pn, (rr, cc, centre, w, h, rad, conf_) = fitter.unproject_single_observation(ellipse_to_map(pe_arr[i]))
                if centre is not None and all(x is not None and np.all(np.isfinite(x)) for x in [gp, gn, pp, pn]):
                    obs[i] = dict(centre=(float(centre[0]), float(centre[1])), gp=gp.copy(), gn=gn.copy(), pp=pp.copy(), pn=pn.copy())
            except Exception:
                obs[i] = None

    def load_obs(o):
        fitter.current_gaze_pos, fitter.current_gaze_neg = o["gp"], o["gn"]
        fitter.current_pupil_3Dcentre_pos, fitter.current_pupil_3Dcentre_neg = o["pp"], o["pn"]
        fitter.current_ellipse_centre = np.array(o["centre"]).reshape(2, 1)

    ok_fit = np.array([o is not None for o in obs]) & ~blink & ~partial & (np.nan_to_num(ratio, nan=9.0) < cfg.fit_max_axis_ratio)
    sel = np.flatnonzero(ok_fit)
    if sel.size > cfg.max_fit_frames:
        sel = sel[np.linspace(0, sel.size - 1, cfg.max_fit_frames).astype(int)]
    if sel.size < 10:
        out["note"] = f"Too few clear open-eye frames for the eyeball model ({sel.size})."
        return out

    np.random.seed(0)
    for i in sel:
        load_obs(obs[i]); fitter.add_to_fitting()
    try:
        with np.errstate(all="ignore"):
            try:
                fitter.fit_projected_eye_centre(ransac=True, max_iters=100, min_distance=max(2000, 10 * N))
            except TypeError:
                fitter.fit_projected_eye_centre(ransac=False)
            fitter.estimate_eye_sphere()
        ec, er = np.asarray(fitter.eye_centre).reshape(-1), float(fitter.aver_eye_radius)
        radius_mm = er / MM2PX
        out["radius_mm"] = float(radius_mm)
        if not (np.all(np.isfinite(ec)) and np.isfinite(er) and er > 0 and ec[2] > 0 and 6 <= radius_mm <= 20):
            out["note"] = f"Eyeball model implausible (radius {radius_mm:.1f} mm, a real eye is about 12 mm)."
            return out
    except Exception as exc:
        out["note"] = f"Eyeball fit failed: {repr(exc)[:150]}"
        return out

    hor, ver, consist = np.full(N, np.nan), np.full(N, np.nan), np.zeros(N, dtype=int)
    with np.errstate(all="ignore"):
        for i, o in enumerate(obs):
            if o is None or blink[i]:
                continue
            try:
                load_obs(o)
                _, n_list, _, ok = fitter.gen_consistent_pupil()
                if bool(ok):                                # ray misses the fitted eyeball -> NaN
                    h_, v_ = _vec_to_angles(n_list[0])
                    if np.isfinite(h_) and np.isfinite(v_):
                        hor[i], ver[i], consist[i] = h_, v_, 1
            except Exception:
                pass
    frac = float(consist[found & ~blink].mean()) if (found & ~blink).any() else 0.0
    out.update(have_angles=True, hor=hor, ver=ver, consistent_frac=frac)
    if frac < 0.6:
        out["note"] = f"Poor eyeball fit (gaze consistent on {100 * frac:.0f}% of frames): treat angles with care."
    return out
