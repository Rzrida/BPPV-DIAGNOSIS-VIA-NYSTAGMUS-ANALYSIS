"""Stage 2: nystagmus detection. Logic is the notebook's detector, plus gap handling.

Differences from the notebook (all marked):
  * input may contain NaN gaps: the signal is split into gap-free stretches and each is analysed
    (the notebook raised an error on any NaN);
  * beats whose slow phase touches a blink are rejected (cfg.reject_blink_overlap);
  * rejection reasons are counted, and a flat-velocity signal is reported instead of silently
    returning nothing.
"""
from collections import Counter

import numpy as np
import pandas as pd
from scipy.stats import linregress

from .config import NystagmusConfig


def find_fast_phase_candidates(velocity, cfg):
    """Group consecutive same-direction samples whose velocity is unusually large (median + MAD).
    Returns (phases, sigma). `start`/`end` are sample positions; velocity[i] spans sample i -> i+1."""
    center = np.median(velocity)
    sigma = 1.4826 * np.median(np.abs(velocity - center))
    if sigma == 0:
        return [], 0.0
    is_fast = np.abs(velocity - center) > cfg.fast_sigma_multiplier * sigma
    sign = np.sign(velocity)
    phases, j = [], 0
    while j < len(velocity):
        if not is_fast[j]:
            j += 1
            continue
        k = j
        while k + 1 < len(velocity) and is_fast[k + 1] and sign[k + 1] == sign[j]:
            k += 1
        phases.append({"start": j, "end": k + 1, "direction": int(sign[j]),
                       "peak_speed": float(np.max(np.abs(velocity[j:k + 1])))})
        j = k + 1
    return phases, float(sigma)


def evaluate_beat(t, y, previous_fast, fast, labels, cfg, blink=None):
    """Return (beat or None, reason). Slow phase = samples between the previous and this fast phase."""
    s, e = previous_fast["end"], fast["start"]
    if e - s + 1 < cfg.min_slow_samples:
        return None, "too_few_samples"
    slow_duration = t[e] - t[s]
    lo, hi = cfg.slow_duration_range_s
    if not (lo <= slow_duration <= hi):
        return None, "slow_duration_out_of_range"
    if t[fast["end"]] - t[fast["start"]] > cfg.max_fast_duration_s:
        return None, "fast_phase_too_long"
    fit = linregress(t[s:e + 1], y[s:e + 1])
    spv, r_squared = fit.slope, fit.rvalue ** 2
    if abs(spv) < cfg.min_abs_spv_deg_s:
        return None, "spv_too_small"
    if not (r_squared >= cfg.min_slow_r2):
        return None, "r2_too_low"
    if np.sign(spv) == fast["direction"]:
        return None, "no_direction_reversal"
    if fast["peak_speed"] < cfg.fast_to_slow_speed_ratio * abs(spv):
        return None, "fast_phase_not_clearly_faster"
    if cfg.reject_blink_overlap and blink is not None and np.any(blink[s:fast["end"] + 1]):
        return None, "touches_blink"
    return {"start_time": float(t[s]), "end_time": float(t[fast["end"]]),
            "pattern": labels[fast["direction"]],
            "slow_velocity": float(spv), "slow_amplitude": float(spv * slow_duration),
            "slow_duration": float(slow_duration), "slow_r_squared": float(r_squared)}, "accepted"


def extract_beats(t, y, labels, cfg, blink=None, index_offset=0):
    """One gap-free stretch. Returns beats, number of candidate pairs, reasons, velocity sigma."""
    velocity = np.diff(y) / np.diff(t)
    phases, sigma = find_fast_phase_candidates(velocity, cfg)
    beats, reasons = [], Counter()
    for i in range(1, len(phases)):
        beat, why = evaluate_beat(t, y, phases[i - 1], phases[i], labels, cfg, blink)
        reasons[why] += 1
        if beat is not None:
            beat["_index"] = index_offset + i
            beats.append(beat)
    return beats, max(len(phases) - 1, 0), reasons, sigma, len(phases)


def longest_repeated_run(beats, pattern, cfg):
    best = run = 0
    last_index = None
    for b in beats:
        if b["pattern"] != pattern:
            run, last_index = 0, None
            continue
        contiguous = last_index is not None and b["_index"] - last_index <= 1 + cfg.max_missed_between_beats
        run = run + 1 if contiguous else 1
        last_index = b["_index"]
        best = max(best, run)
    return best


def classify(beats, cfg):
    """Return (label, direction_consistency, dominant_pattern)."""
    n = len(beats)
    if n == 0:
        return "Neither detected", None, None
    counts = pd.Series([b["pattern"] for b in beats]).value_counts()
    dominant = counts.idxmax()
    consistency = float(counts[dominant] / n)
    if n < cfg.min_accepted_beats:
        return "Inconclusive (too few valid beats)", consistency, dominant
    if consistency < cfg.min_direction_consistency:
        return "Inconclusive (conflicting patterns)", consistency, dominant
    if longest_repeated_run(beats, dominant, cfg) < cfg.min_accepted_beats:
        return "Inconclusive (beats not repeated in succession)", consistency, dominant
    return dominant, consistency, dominant


def _finite_runs(t, y):
    """(start, stop) index pairs of contiguous finite samples."""
    ok = np.isfinite(t) & np.isfinite(y)
    runs, i, n = [], 0, len(ok)
    while i < n:
        if not ok[i]:
            i += 1
            continue
        j = i
        while j < n and ok[j]:
            j += 1
        runs.append((i, j))
        i = j
    return runs


def detect_axis(t, y, labels, cfg=None, blink=None):
    """Run the detector on one gaze channel. Gaps (NaN) split the signal into separate stretches."""
    cfg = cfg or NystagmusConfig()
    t, y = np.asarray(t, float), np.asarray(y, float)
    blink = None if blink is None else np.asarray(blink, bool)

    beats, reasons, n_cand, offset = [], Counter(), 0, 0
    flat_stretches, analysed = 0, 0
    for a, b in _finite_runs(t, y):
        if b - a < cfg.min_segment_samples or np.any(np.diff(t[a:b]) <= 0):
            continue
        analysed += 1
        seg_blink = None if blink is None else blink[a:b]
        seg_beats, seg_cand, seg_reasons, sigma, n_phases = extract_beats(
            t[a:b], y[a:b], labels, cfg, seg_blink, index_offset=offset)
        # shift segment-local time stays global because t[a:b] is global time
        beats += seg_beats
        reasons.update(seg_reasons)
        n_cand += seg_cand
        offset += n_phases + 2 + cfg.max_missed_between_beats      # a run never spans two stretches
        if sigma == 0:
            flat_stretches += 1

    label, consistency, dominant = classify(beats, cfg)
    spvs = [b["slow_velocity"] for b in beats]
    notes = []
    if analysed == 0:
        notes.append("No gap-free stretch long enough to analyse.")
    if flat_stretches:
        notes.append(f"{flat_stretches} stretch(es) skipped: the robust velocity spread (MAD) was 0, "
                     "so the relative fast-phase test cannot run (signal flat or noise-free).")
    return {
        "label": label,
        "dominant_pattern": dominant,
        "accepted_beats": len(beats),
        "candidate_pairs": n_cand,
        "median_spv": float(np.median(spvs)) if spvs else None,
        "direction_consistency": consistency,
        "rejections": dict(reasons),
        "notes": notes,
        "beats": [{"start": b["start_time"], "end": b["end_time"], "pattern": b["pattern"],
                   "spv": b["slow_velocity"], "amplitude": b["slow_amplitude"],
                   "duration": b["slow_duration"], "r2": b["slow_r_squared"]} for b in beats],
    }


def merge_beats_to_segments(beats, axis, gap_s=0.2):
    """Consecutive same-pattern beats become one shaded run for the app."""
    segs = []
    for b in sorted(beats, key=lambda x: x["start"]):
        if segs and segs[-1]["pattern"] == b["pattern"] and b["start"] - segs[-1]["end"] <= gap_s:
            segs[-1]["end"] = b["end"]
            segs[-1]["beats"] += 1
        else:
            segs.append({"axis": axis, "start": b["start"], "end": b["end"],
                         "pattern": b["pattern"], "beats": 1})
    return segs
