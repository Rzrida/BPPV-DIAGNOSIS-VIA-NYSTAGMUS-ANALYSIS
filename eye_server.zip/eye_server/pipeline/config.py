"""All tunable settings in one place. Defaults copy the two notebooks exactly."""
from dataclasses import dataclass


@dataclass
class CropConfig:                      # notebook: ellseg cell 1
    n_samples: int = 60
    crop_scale: float = 2.5
    min_crop_frac: float = 0.4
    wavelet: str = "db2"
    levels: int = 3
    analysis_w: int = 256


@dataclass
class EllSegConfig:                    # notebook: ellseg cells 2 and 3
    repo_dir: str = "EllSeg"
    weights: str = "all.git_ok"
    ellipses: int = 1
    net_h: int = 240
    net_w: int = 320
    # blink / occlusion
    blink_min_contrast_frac: float = 0.25
    blink_max_axis_ratio: float = 3.0
    blink_pad: int = 2
    partial_occ: float = 0.25
    max_gap_s: float = 0.6
    # DeepVOG eyeball model (same constants as the notebook)
    use_eyeball_model: bool = True
    deepvog_dir: str = "DeepVOG"
    focal_length_mm: float = 6.0
    sensor_mm: tuple = (3.6, 4.8)
    min_fit_frames: int = 100
    max_fit_frames: int = 800
    fit_max_axis_ratio: float = 1.6
    flip_horizontal: bool = False
    flip_vertical: bool = False
    # velocity / SPV
    vel_win_s: float = 0.10
    qp_vel: float = 40.0
    qp_pad: int = 2
    spv_win_s: float = 1.0
    # iris used as a ruler when the eyeball model is rejected
    approx_deg: bool = True
    iris_diam_mm: float = 11.7
    eye_r_mm: float = 12.0


@dataclass
class NystagmusConfig:                 # notebook: nystagmus detector (all experimental, not clinical)
    min_abs_spv_deg_s: float = 2.0
    min_slow_r2: float = 0.80
    min_direction_consistency: float = 0.70
    min_accepted_beats: int = 3
    slow_duration_range_s: tuple = (0.04, 2.5)
    fast_sigma_multiplier: float = 5.0
    max_fast_duration_s: float = 0.3
    fast_to_slow_speed_ratio: float = 3.0
    min_slow_samples: int = 4
    max_missed_between_beats: int = 1
    # ADDED (not in the notebook): reject beats whose slow phase touches a blink,
    # because blink gaps are bridged by straight lines that look like perfect slow phases.
    reject_blink_overlap: bool = True
    min_segment_samples: int = 8       # shortest gap-free stretch that is analysed


# +1 = up / right, -1 = down / left (names are by FAST-phase direction)
VERTICAL_LABELS = {-1: "DBN", +1: "UBN"}
HORIZONTAL_LABELS = {-1: "Left-beating", +1: "Right-beating"}
