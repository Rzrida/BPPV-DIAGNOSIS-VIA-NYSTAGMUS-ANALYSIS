"""Stage 1a: find the eye (wavelet eye finder) and cut a 4:3 window around it. Port of ellseg cell 1."""
import shutil
import subprocess
from pathlib import Path

import cv2
import numpy as np
import pywt

from .config import CropConfig


def _opens(p):
    c = cv2.VideoCapture(str(p))
    ok = c.isOpened() and c.read()[0]
    c.release()
    return ok


def _ffmpeg():
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()


def ensure_readable(video_path, workdir):
    """Some phone codecs (for example iPhone .mov/HEVC) do not open in OpenCV: convert once with ffmpeg."""
    if _opens(video_path):
        return str(video_path)
    out = Path(workdir) / "converted.mp4"
    r = subprocess.run([_ffmpeg(), "-y", "-i", str(video_path), "-an", "-vcodec", "libx264",
                        "-pix_fmt", "yuv420p", str(out)], capture_output=True, text=True)
    if r.returncode != 0 or not _opens(out):
        raise ValueError("The video could not be read (unsupported format or corrupt file).")
    return str(out)


def _eye_score_map(bgr, cfg, aw, ah):
    """High where the image is DARK (pupil/iris) AND rich in wavelet edge energy (lids, lashes, glints)."""
    g = cv2.resize(cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY), (aw, ah), interpolation=cv2.INTER_AREA).astype(np.float32) / 255.0
    coeffs = pywt.wavedec2(g, cfg.wavelet, level=cfg.levels)
    energy = np.zeros((ah, aw), np.float32)
    for (cH, cV, cD) in coeffs[1:]:
        e = np.sqrt(cH ** 2 + cV ** 2 + cD ** 2).astype(np.float32)
        energy += cv2.resize(e, (aw, ah), interpolation=cv2.INTER_LINEAR)
    energy = cv2.GaussianBlur(energy, (0, 0), max(ah, aw) / 40)
    energy /= energy.max() + 1e-9
    a = cv2.resize(coeffs[0].astype(np.float32), (aw, ah), interpolation=cv2.INTER_LINEAR)
    a = (a - a.min()) / (a.max() - a.min() + 1e-9)
    s = (1.0 - a) * energy
    m = int(0.05 * min(ah, aw))
    s[:m, :] = 0; s[-m:, :] = 0; s[:, :m] = 0; s[:, -m:] = 0
    return s / (s.max() + 1e-9)


def find_eye_crop(video_path, cfg=None):
    """Returns the crop box (x0, y0, w, h) plus basic video facts."""
    cfg = cfg or CropConfig()
    cap = cv2.VideoCapture(str(video_path))
    W, H = int(cap.get(3)), int(cap.get(4))
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    n_in = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if n_in <= 0:                                       # some containers do not report a frame count
        n_in = 0
        while cap.read()[0]:
            n_in += 1
        cap.release()
        cap = cv2.VideoCapture(str(video_path))

    want = set(np.linspace(0, max(n_in - 1, 0), cfg.n_samples).astype(int).tolist())
    aw = min(cfg.analysis_w, W); ah = int(round(H * aw / W)); sc = W / aw
    heat_sum, n_maps, i = None, 0, 0
    while True:
        ok, f = cap.read()
        if not ok:
            break
        if i in want:                                   # maps are averaged on the fly: frames are not kept in memory
            m = _eye_score_map(f, cfg, aw, ah)
            heat_sum = m if heat_sum is None else heat_sum + m
            n_maps += 1
        i += 1
    cap.release()
    n_in = i
    if n_maps == 0:
        raise ValueError("The video has no readable frames.")

    heat_map = cv2.GaussianBlur(heat_sum / n_maps, (0, 0), max(ah, aw) / 50)
    py, px = np.unravel_index(np.argmax(heat_map), heat_map.shape)
    mask = (heat_map >= 0.5 * heat_map.max()).astype(np.uint8)
    _, lab = cv2.connectedComponents(mask)
    ys, xs = np.nonzero(lab == lab[py, px])
    ew = max(xs.max() - xs.min() + 1, (ys.max() - ys.min() + 1) * 4 / 3)
    cx, cy, ew = px * sc, py * sc, ew * sc

    # 4:3 crop, sizes multiples of (8, 6); a pure cut (no rescaling)
    k_max = int(min(W // 8, H // 6))
    k = int(np.clip(round(cfg.crop_scale * ew / 8), max(1, int(cfg.min_crop_frac * k_max)), k_max))
    cw, ch = 8 * k, 6 * k
    x0 = int(np.clip(round(cx - cw / 2), 0, W - cw))
    y0 = int(np.clip(round(cy - ch / 2), 0, H - ch))
    return {"x0": x0, "y0": y0, "w": cw, "h": ch, "fps": float(fps),
            "width": W, "height": H, "n_frames": n_in,
            "eye_centre": [float(cx), float(cy)], "eye_width": float(ew)}


def write_cropped_video(video_path, crop, out_path):
    """Pure cut of the crop window, same frame rate. Returns the number of frames written."""
    cap = cv2.VideoCapture(str(video_path))
    wr = cv2.VideoWriter(str(out_path), cv2.VideoWriter_fourcc(*"mp4v"), crop["fps"], (crop["w"], crop["h"]))
    n = 0
    x0, y0, w, h = crop["x0"], crop["y0"], crop["w"], crop["h"]
    while True:
        ok, f = cap.read()
        if not ok:
            break
        wr.write(f[y0:y0 + h, x0:x0 + w])
        n += 1
    cap.release(); wr.release()
    if n == 0:
        raise ValueError("No frames could be written to the cropped video.")
    return n
