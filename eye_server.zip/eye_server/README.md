# Eye gaze analysis server

One function does everything: video in, JSON out.

```
video -> eye finder + 4:3 crop -> EllSeg (every frame) -> blink detection
      -> eyeball model / iris-ruler angles -> velocity + SPV -> gaze table
      -> nystagmus detector (vertical + horizontal) -> JSON for the phone
```

| File | Comes from |
|---|---|
| `pipeline/eye_crop.py` | EllSeg notebook, cell 1 |
| `pipeline/ellseg_stage.py` | EllSeg notebook, cell 2 |
| `pipeline/gaze_signal.py` | EllSeg notebook, cell 3 |
| `pipeline/nystagmus_stage.py` | nystagmus notebook (the detector) |
| `pipeline/run.py` | glue: `analyze(video)` |
| `pipeline/config.py` | every threshold, with the notebook's defaults |
| `server/app.py` | FastAPI: `POST /analyze`, `GET /jobs/{id}`, `GET /health` |

## Differences from the notebooks (on purpose)

1. **Gaps (NaN) are allowed.** The notebook crashed on any NaN. Now the signal is split into gap-free
   stretches and each is analysed; a run of beats never spans a gap.
2. **Beats whose slow phase touches a blink are rejected** (`reject_blink_overlap`, default on).
   Blink gaps are bridged by straight lines, which look like perfect slow phases. Set it to `False` for exact notebook behaviour.
3. Rejection reasons are counted per axis (`rejections`), and a "MAD = 0" skip is reported in `notes` instead of silently returning nothing.
4. Left/right flips (`flip_horizontal`, `flip_vertical`) apply in every angle mode (the notebook applied them only to eyeball-model angles). Defaults are off.
5. Models are loaded once at server start, not per video. Frames are not kept in memory during eye finding.
6. Uploaded videos are **deleted right after processing** (`KEEP_VIDEOS=1` keeps them).

## Test without a GPU (mock mode)

```
pip install -r requirements.txt
MOCK_PIPELINE=1 MOCK_KIND=DBN uvicorn server.app:app --host 0.0.0.0 --port 8000 --app-dir .
python -m pytest tests
```
Mock mode skips EllSeg and sends a synthetic recording through the real nystagmus stage.

## First real test on Kaggle (GPU, Internet ON)

1. Upload this folder as a Kaggle dataset (or zip and `!unzip` it into `/kaggle/working/eye_server`).
2. In a notebook cell:
```python
!pip install -q fastapi uvicorn python-multipart PyWavelets imageio-ffmpeg pyngrok
import os, sys, threading, uvicorn
os.chdir("/kaggle/working/eye_server"); sys.path.insert(0, "/kaggle/working/eye_server")
sys.path.insert(0, "/kaggle/working/eye_server/server")
os.environ["API_KEY"] = "choose-a-secret"
import app as server
threading.Thread(target=uvicorn.Server(uvicorn.Config(server.app, host="0.0.0.0", port=8000)).run, daemon=True).start()

from pyngrok import ngrok
ngrok.set_auth_token("YOUR_NGROK_TOKEN")        # free account at ngrok.com
print(ngrok.connect(8000).public_url)           # -> put this in the app as baseUrl
```
3. First call is slow: it clones EllSeg and loads the weights.
4. The notebook session must stay running while you test.

## Run the real pipeline on a file (no server)

```python
from pipeline.ellseg_stage import EllSegRunner
from pipeline.run import analyze
r = analyze("my_eye_video.mp4", EllSegRunner())
print(r["headline"], r["meta"]["angle_mode"], r["meta"]["timings_s"])
```

## JSON the app receives (main keys)

```
overall, headline, warnings[]
meta{fps, unit, angle_mode, duration_s, blink_frames, timings_s, ...}
timestamps[], horizontal_angle[], vertical_angle[], velocity_h/v[], spv_h/v[], blink[]   (null where unknown)
nystagmus{vertical, horizontal}{label, accepted_beats, median_spv, direction_consistency, rejections, notes, beats[]}
nystagmus_segments[]{axis, start, end, pattern, beats}      (merged runs for shading)
```
Thresholds are experimental engineering values, not validated clinical cutoffs.
